﻿namespace Spotify.Classes
{
    public class DownloadMusic
    {
        public string contentType { get; set; }
        public string fileName { get; set; }
        public byte[] fileBytes { get; set; }
    }
}
