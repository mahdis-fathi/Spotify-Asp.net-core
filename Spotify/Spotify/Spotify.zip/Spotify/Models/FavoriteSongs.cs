﻿namespace Spotify.Models
{
    public class FavoriteSongs
    {
        public int ID { get; set; }
        public string UserId { get; set; }
        public int SongId { get; set;}
    }
}
