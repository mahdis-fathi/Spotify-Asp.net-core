﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Spotify.Models;
using Spotify.Models.context;
using Spotify.Services;
using System.Diagnostics;

namespace Spotify.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IHome _home;
        private readonly AppDbContext _context;

        public HomeController(ILogger<HomeController> logger, IHome home, AppDbContext appDb)
        {
            _logger = logger;
            _home = home;
            _context = appDb;
        }

        public async Task<IActionResult> Index()
        {
            var songs = _context.Songs.ToList();
            foreach(var song in songs) 
            {
                song.Artist = await _context.Artists
                    .FirstOrDefaultAsync(a => a.Id == song.ArtistId);
            }
            return View(songs);
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}